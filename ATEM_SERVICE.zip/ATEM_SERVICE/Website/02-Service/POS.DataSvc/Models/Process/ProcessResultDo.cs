﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POS.DataSvc.Models
{
    public partial class ProcessResultDo : Utils.SQL.ASQLDbResult
    {
    }
}
