﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Master.DataSvc.Models
{
    public partial class LocationCodeAutoCompleteDo
    {
        public string LOC_CD { get; set; }
        public string LOC_DESC { get; set; }
        public string DisplayText { get; set; }
    }
}
