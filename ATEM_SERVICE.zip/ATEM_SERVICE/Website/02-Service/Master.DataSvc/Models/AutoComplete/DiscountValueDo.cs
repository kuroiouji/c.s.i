﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Master.DataSvc.Models
{
    public partial class DiscountValueAutoCompleteDo
    {
        public decimal DiscountValue { get; set; }
        public string DiscountValueText { get; set; }
    }
}
