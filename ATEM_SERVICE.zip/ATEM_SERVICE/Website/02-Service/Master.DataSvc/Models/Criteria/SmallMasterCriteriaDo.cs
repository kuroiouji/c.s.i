﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Master.DataSvc.Models
{
    public class SmallMasterCriteriaDo
    {
        public string MSTCode { get; set; }
    }
}
