﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web
{
    public partial class Constants
    {
        public static List<Models.ScreenDo> SCREEN_LIST { get; set; }
    }
}
