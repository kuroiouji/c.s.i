﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common.Api.Models
{
    public class TokenDo
    {
        public string Value { get; set; }
    }
}
