﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Master.DataSvc.Models
{
    public partial class DistrictAutoCompleteDo
    {
        public string DistrictID { get; set; }
        public string CantonID { get; set; }
        public string DistrictName { get; set; }
    }
}
