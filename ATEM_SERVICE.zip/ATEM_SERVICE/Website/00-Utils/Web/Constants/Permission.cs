﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web
{
    public partial class Constants
    {
        public static int LOGIN_WAITING_TIME { get; private set; }
        public static int MAXIMUM_LOGIN_FAIL { get; private set; }
        public static string PROCESS_TIME { get; private set; }
    }
}
