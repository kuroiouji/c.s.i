﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utils
{
    public class Constants
    {
        public static string TEMP_PATH { get; private set; }
    }
}
