﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Master.DataSvc.Models
{
    public partial class ProvinceAutoCompleteDo
    {
        public string ProvinceID { get; set; }
        public string ProvinceName { get; set; }
    }
}
